"""
CAPRI-Python test suite (pytest).

Covers the invariants that matter for a trustworthy model:
  - data loads and has the expected structure
  - the data validator runs and catches inconsistency
  - base-year market fidelity (the model's headline claim: 12/12 @ 0%)
  - supply responds to prices with the right sign and no numerical blow-ups
  - each module runs end to end

Run:  pytest capri_python/tests/ -v
"""
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import numpy as np
import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parents[2]
DATA_DIR = ROOT / "capri_data"


@pytest.fixture(scope="session")
def data():
    from capri_python.data.loaders import load_all_data
    return load_all_data(DATA_DIR)


@pytest.fixture(scope="session")
def model():
    from capri_python.model import CAPRIModel
    return CAPRIModel(data_dir=str(DATA_DIR), verbose=False)


def test_data_loads(data):
    assert "areas" in data
    assert "world_prices" in data
    assert len(data["areas"]) >= 200
    assert len(data["world_prices"]) > 0


def test_data_validator_runs():
    from capri_python.data.validate_data import validate_data
    rep = validate_data(str(DATA_DIR))
    assert rep.n_fail == 0, f"validator reported failures: {rep.summary()}"


def test_validator_has_vintage_check():
    from capri_python.data.validate_data import validate_data
    rep = validate_data(str(DATA_DIR))
    names = [c[0] for c in rep.checks]
    assert any("vintage" in n for n in names)


def test_no_negative_base_quantities(data):
    df = data["areas"].select_dtypes("number")
    assert (df.values >= 0).all()


def test_base_year_market_fidelity(data):
    from capri_python.market.market_module import MarketModule
    from capri_python.data.definitions import MARKET_COMMODITIES

    mm = MarketModule(data)
    exo = pd.DataFrame(0.0, index=["EU27"], columns=MARKET_COMMODITIES)
    for c in MARKET_COMMODITIES:
        if c in mm.base_production.columns:
            exo.at["EU27", c] = mm.base_production.at["EU27", c]

    eq = mm.solve(exogenous_supply=exo, max_iter=150, tolerance=0.01)
    assert eq.converged

    ref = {"SWHE": 148, "BARL": 145, "CORN": 148, "RAPE": 321, "SOYA": 293,
           "BEEF": 3692, "PORK": 1613, "POUL": 1405, "MILK": 319,
           "BUTR": 3782, "CHES": 2581, "SKIM": 1429}
    within = sum(1 for c, r in ref.items()
                 if abs((eq.world_prices.get(c, 0) - r) / r) <= 0.15)
    assert within == 12, f"only {within}/12 within 15%"


def test_supply_responds_positively_to_price(model):
    sm = model.supply_module
    reg = "DE11"
    base = sm.run(price_signals=None, regions=[reg])
    q0 = base[reg].activities.get("SWHE", 0)
    sig = pd.Series(0.0, index=model.data["world_prices"].index)
    sig["SWHE"] = 0.20
    up = sm.run(price_signals=sig, regions=[reg])
    q1 = up[reg].activities.get("SWHE", 0)
    assert q1 >= q0 - 1e-6


def test_supply_no_blowup(model):
    sm = model.supply_module
    for reg in list(model.data["areas"].index[:8]):
        base = sm.run(price_signals=None, regions=[reg])
        for act in ["SWHE", "CORN", "RAPE", "PULS"]:
            q0 = base[reg].activities.get(act, 0)
            if q0 <= 0.001:
                continue
            sig = pd.Series(0.0, index=model.data["world_prices"].index)
            sig[act] = 0.20
            s = sm.run(price_signals=sig, regions=[reg])
            q1 = s[reg].activities.get(act, 0)
            assert q1 / q0 < 10, f"{reg} {act} blew up"


def test_full_run_all_modules(model):
    regions = list(model.data["areas"].index[:5])
    r = model.run(scenario="BASELINE", max_outer_iter=1, market_max_iter=50,
                  regions=regions, run_environmental=True, run_feed=True,
                  run_biofuel=True)
    for k in ["supply", "market", "environmental", "feed", "biofuel"]:
        assert r[k] is not None


def test_biofuel_scenario_increases_output(model):
    bm = model.biofuel_module
    low = bm.run(mandate_share=0.065)
    high = bm.run(mandate_share=0.14)
    assert high.bioethanol_kt > low.bioethanol_kt
    assert high.biodiesel_kt > low.biodiesel_kt


if __name__ == "__main__":
    sys.exit(pytest.main([__file__, "-v"]))
