"""
CAPRI-Python data validator.

Checks the live data in capri_data/ against MANIFEST.json and runs a set of
integrity and consistency tests. Its job is to catch the data-management
failure modes that matter at this project's scale — not performance, but
*correctness*: missing files, shape drift, vintage-mixing, unit surprises,
and broken cross-file references.

Run standalone:   python validate_data.py
Or import:        from validate_data import validate_data; validate_data("capri_data")

Storage note: the data is ~3.6 MB of flat CSV/JSON. That is deliberately not a
database or Parquet store — at this scale flat files load in under two seconds
and stay human-readable. The right data-management tool here is validation +
a manifest, which is what this module provides.
"""
from __future__ import annotations
import json
from pathlib import Path
import pandas as pd


class ValidationReport:
    def __init__(self):
        self.checks = []      # (name, status, detail)
        self.n_pass = 0
        self.n_warn = 0
        self.n_fail = 0

    def add(self, name, status, detail=""):
        self.checks.append((name, status, detail))
        if status == "PASS": self.n_pass += 1
        elif status == "WARN": self.n_warn += 1
        else: self.n_fail += 1

    def summary(self):
        return f"{self.n_pass} pass, {self.n_warn} warn, {self.n_fail} fail"

    def print(self):
        icons = {"PASS": "  ok  ", "WARN": " warn ", "FAIL": " FAIL "}
        for name, status, detail in self.checks:
            line = f"[{icons.get(status, status)}] {name}"
            if detail:
                line += f"  — {detail}"
            print(line)
        print("-" * 60)
        print(f"  {self.summary()}")


def validate_data(data_dir="capri_data") -> ValidationReport:
    D = Path(data_dir)
    rep = ValidationReport()

    # --- 1. Manifest present and parseable ---
    man_path = D / "MANIFEST.json"
    if not man_path.exists():
        rep.add("manifest exists", "FAIL", "MANIFEST.json missing")
        return rep
    manifest = json.load(open(man_path))
    files = manifest.get("files", {})
    rep.add("manifest parseable", "PASS", f"{len(files)} live files catalogued")

    # --- 2. Every catalogued live file exists ---
    missing = [fn for fn in files if not (D / fn).exists()]
    if missing:
        rep.add("all live files present", "FAIL", f"missing: {missing}")
    else:
        rep.add("all live files present", "PASS", f"{len(files)}/{len(files)}")

    # --- 3. Shape matches manifest (catches silent truncation/corruption) ---
    drift = []
    for fn, meta in files.items():
        p = D / fn
        if not p.exists() or not fn.endswith(".csv"):
            continue
        exp = meta.get("shape") or {}
        if "rows" not in exp:
            continue
        try:
            df = pd.read_csv(p, index_col=0)
            if df.shape[0] != exp["rows"]:
                drift.append(f"{fn}: {df.shape[0]} rows (manifest {exp['rows']})")
        except Exception as e:
            drift.append(f"{fn}: unreadable ({str(e)[:30]})")
    if drift:
        rep.add("file shapes match manifest", "WARN", "; ".join(drift[:3]))
    else:
        rep.add("file shapes match manifest", "PASS")

    # --- 4. Vintage consistency: the base-year group must share one vintage ---
    base_group = {fn: m["vintage"] for fn, m in files.items()
                  if m.get("domain") in ("supply", "prices")
                  and m.get("vintage") not in ("static", "2006")}
    vintages = set(base_group.values())
    if len(vintages) > 1:
        rep.add("base-year vintage consistent", "WARN",
                f"base group spans {sorted(vintages)} — mixing vintages risks "
                f"inconsistent calibration")
    else:
        rep.add("base-year vintage consistent", "PASS",
                f"base group all {vintages.pop() if vintages else '?'}")

    # --- 5. Key economic sanity checks on live values ---
    try:
        wp = pd.read_csv(D / "world_prices.csv", index_col=0)
        col = wp.columns[0]
        # livestock prices should exceed crop prices (basic economics)
        beef = wp.at["BEEF", col] if "BEEF" in wp.index else None
        wheat = wp.at["SWHE", col] if "SWHE" in wp.index else None
        if beef and wheat and beef > wheat * 5:
            rep.add("price levels sane (beef >> wheat)", "PASS",
                    f"beef {beef:.0f} vs wheat {wheat:.0f} EUR/t")
        else:
            rep.add("price levels sane", "WARN",
                    f"beef {beef}, wheat {wheat} — check units")
    except Exception as e:
        rep.add("price levels sane", "WARN", str(e)[:40])

    # --- 6. No negative quantities in base areas/yields ---
    for fn in ["base_areas.csv", "yields.csv", "animal_numbers.csv"]:
        p = D / fn
        if not p.exists():
            continue
        try:
            df = pd.read_csv(p, index_col=0).select_dtypes("number")
            neg = (df < 0).sum().sum()
            if neg > 0:
                rep.add(f"non-negative values ({fn})", "FAIL", f"{neg} negatives")
            else:
                rep.add(f"non-negative values ({fn})", "PASS")
        except Exception as e:
            rep.add(f"non-negative values ({fn})", "WARN", str(e)[:30])

    # --- 7. Trade flows reference valid regions/commodities ---
    try:
        tf = pd.read_csv(D / "trade_flows.csv")
        rep.add("trade flows loadable", "PASS", f"{tf.shape[0]} rows")
    except Exception as e:
        rep.add("trade flows loadable", "WARN", str(e)[:40])

    # --- 8. Synthetic-data detection (from the sourcing registry) ---
    reg_path = D / "DATA_SOURCING_REGISTRY.json"
    if reg_path.exists():
        reg = json.load(open(reg_path))
        synthetic_live = []
        for fn, meta in reg.get("datasets", {}).items():
            if meta.get("nature") == "SYNTHETIC_FALLBACK":
                # is the real file actually absent (so the fallback fires)?
                if not (D / fn).exists():
                    synthetic_live.append(fn)
        if synthetic_live:
            rep.add("no live synthetic data", "WARN",
                    f"{len(synthetic_live)} dataset(s) using synthetic fallback: "
                    f"{', '.join(synthetic_live)} — see registry for real source")
        else:
            rep.add("no live synthetic data", "PASS")
        # report the data-nature breakdown
        from collections import Counter
        nat = Counter(m.get("nature") for m in reg["datasets"].values())
        rep.add("data provenance known", "PASS",
                f"{nat.get('REAL_CAPRI',0)} CAPRI, {nat.get('REAL_FAO',0)} FAO, "
                f"{nat.get('SYNTHETIC_FALLBACK',0)} synthetic")
    else:
        rep.add("sourcing registry present", "WARN",
                "DATA_SOURCING_REGISTRY.json missing")

    return rep


if __name__ == "__main__":
    import sys
    d = sys.argv[1] if len(sys.argv) > 1 else "capri_data"
    print(f"Validating data in: {d}\n" + "=" * 60)
    report = validate_data(d)
    report.print()
