# CAPRI-Python Documentation

- **[DATA_SOURCING_GUIDE.md](DATA_SOURCING_GUIDE.md)** — which data, which vintage, is it
  real, and where the best updated version comes from.
- **[DATA_ACQUISITION_REFERENCE.md](DATA_ACQUISITION_REFERENCE.md)** — exact filenames,
  GDX symbols, and how to obtain CAPRI data (SVN, downloads).
- **[DATA_LOCATION_MAP.md](DATA_LOCATION_MAP.md)** — folder/file/symbol map for pulling
  data from a CAPRI installation.

For model status and validation, see the top-level [README](../README.md).
For per-file provenance, see `capri_data/MANIFEST.json` and
`capri_data/DATA_SOURCING_REGISTRY.json`.
